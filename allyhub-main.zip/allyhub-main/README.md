# AllyHub-teste

Simples form com validacao e mascaras criada usando react,react-boostrap,formik,axios e multiselect-react-dropdown

# Instrucoes
* 1-De clone no repositior, instale node e npm na sua maquina
* 2-Usando um terminal entre na pasta do projeto, use npm i para instalar os node_modules
* 3-Use npm start e espere a pagina abri no localhost:3000

## Technologias

* JS
* React
* React-Bootstrap
* Formik
* Axios
* Multi-Select-React-Dropdown

## Ferramentas

* Visual Studio Code
* Linux terminal
* Git and GitHub
* Node Libraries
* WebPack


## Author

GitHub: [fabioschitini](https://github.com/fabioschitini)
